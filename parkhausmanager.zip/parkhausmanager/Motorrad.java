package parkhausmanager;

public class Motorrad extends Fahrzeug{

	public Motorrad(String nummernschild) {
		super(nummernschild);
	}

}
