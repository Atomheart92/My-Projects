package parkhausmanager;

public class Auto extends Fahrzeug{

	public Auto(String nummernschild) {
		super(nummernschild);		
	}

}
